# GMACH-ERP

Personal ERP web application built with Next.js + Supabase.

Modules:
- Dashboard
- Attendance
- HR / Employee Master
- Inventory
- Leave Management
- Profile
- Role-based access

## Stack
Next.js App Router + TypeScript + Supabase PostgreSQL/Auth.

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in Supabase SQL Editor.
3. Create a `.env.local` from `.env.example`.
4. Run `npm install`.
5. Run `npm run dev`.

For deployment, import this GitHub repository into Vercel and add the two environment variables.
