-- GMACH-ERP Supabase database setup
-- Run this entire file in Supabase SQL Editor.

create extension if not exists "pgcrypto";

create table if not exists public.employees (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete cascade,
  employee_id text unique not null,
  name text not null,
  email text not null,
  role text not null default 'Employee' check (role in ('Admin','HR','Manager','Inventory','Employee')),
  department text default '',
  designation text default '',
  phone text default '',
  joining_date date,
  status text not null default 'Active' check (status in ('Active','Inactive')),
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  work_date date not null,
  check_in timestamptz,
  check_out timestamptz,
  unique(user_id, work_date)
);

create table if not exists public.inventory (
  id uuid primary key default gen_random_uuid(),
  item_code text unique not null,
  item_name text not null,
  category text default '',
  brand text default '',
  serial_no text default '',
  quantity integer not null default 0 check (quantity >= 0),
  min_quantity integer not null default 0 check (min_quantity >= 0),
  location text default '',
  supplier text default '',
  purchase_date date,
  assigned_to text default '',
  status text not null default 'Available',
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_transactions (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.inventory(id) on delete cascade,
  transaction_type text not null check (transaction_type in ('Issue','Return')),
  quantity integer not null check (quantity > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.leaves (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  leave_type text not null,
  from_date date not null,
  to_date date not null,
  reason text default '',
  status text not null default 'Pending' check (status in ('Pending','Approved','Rejected')),
  created_at timestamptz not null default now()
);

alter table public.employees enable row level security;
alter table public.attendance enable row level security;
alter table public.inventory enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.leaves enable row level security;

-- Helper: current user's role
create or replace function public.my_role()
returns text language sql stable security definer set search_path=public
as $$ select role from public.employees where user_id=auth.uid() limit 1 $$;

-- Employees
drop policy if exists "employees_read" on public.employees;
create policy "employees_read" on public.employees for select to authenticated
using (user_id=auth.uid() or public.my_role() in ('Admin','HR','Manager'));

drop policy if exists "employees_admin_insert" on public.employees;
create policy "employees_admin_insert" on public.employees for insert to authenticated
with check (public.my_role() in ('Admin','HR'));

drop policy if exists "employees_admin_update" on public.employees;
create policy "employees_admin_update" on public.employees for update to authenticated
using (public.my_role() in ('Admin','HR')) with check (public.my_role() in ('Admin','HR'));

-- Attendance
drop policy if exists "attendance_read" on public.attendance;
create policy "attendance_read" on public.attendance for select to authenticated
using (user_id=auth.uid() or public.my_role() in ('Admin','HR','Manager'));

drop policy if exists "attendance_insert_own" on public.attendance;
create policy "attendance_insert_own" on public.attendance for insert to authenticated
with check (user_id=auth.uid());

drop policy if exists "attendance_update_own" on public.attendance;
create policy "attendance_update_own" on public.attendance for update to authenticated
using (user_id=auth.uid() or public.my_role() in ('Admin','HR'))
with check (user_id=auth.uid() or public.my_role() in ('Admin','HR'));

-- Inventory
drop policy if exists "inventory_read" on public.inventory;
create policy "inventory_read" on public.inventory for select to authenticated using (true);

drop policy if exists "inventory_write" on public.inventory;
create policy "inventory_write" on public.inventory for all to authenticated
using (public.my_role() in ('Admin','Inventory','HR'))
with check (public.my_role() in ('Admin','Inventory','HR'));

drop policy if exists "inventory_txn_write" on public.inventory_transactions;
create policy "inventory_txn_write" on public.inventory_transactions for all to authenticated
using (public.my_role() in ('Admin','Inventory','HR'))
with check (public.my_role() in ('Admin','Inventory','HR'));

-- Leave
drop policy if exists "leave_read" on public.leaves;
create policy "leave_read" on public.leaves for select to authenticated
using (user_id=auth.uid() or public.my_role() in ('Admin','HR','Manager'));

drop policy if exists "leave_insert" on public.leaves;
create policy "leave_insert" on public.leaves for insert to authenticated
with check (user_id=auth.uid());

drop policy if exists "leave_manager_update" on public.leaves;
create policy "leave_manager_update" on public.leaves for update to authenticated
using (public.my_role() in ('Admin','HR','Manager'))
with check (public.my_role() in ('Admin','HR','Manager'));

-- IMPORTANT:
-- 1) Create the first user in Supabase Authentication > Users.
-- 2) Then insert its profile below, replacing USER_UUID.
-- insert into public.employees(user_id,employee_id,name,email,role,department,designation)
-- values ('USER_UUID','ADMIN001','Your Name','your@email.com','Admin','Administration','Administrator');
