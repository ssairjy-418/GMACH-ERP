import { createClient } from "@/lib/supabase/server";
import EmployeeForm from "@/components/EmployeeForm";
export default async function Employees(){
 const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)return null;
 const {data:me}=await s.from("employees").select("role").eq("user_id",user.id).maybeSingle();const allowed=["Admin","HR"].includes(me?.role??"");
 const {data:rows}=await s.from("employees").select("*").order("created_at",{ascending:false});
 return <main className="wrap"><div className="title"><div><h1>HR / Employee Master</h1><div className="muted">Employee records and roles</div></div></div>
 {allowed&&<EmployeeForm/>}<div className="card" style={{marginTop:14}}><h2>Employees</h2><div className="tablewrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Designation</th><th>Status</th></tr></thead><tbody>{(rows??[]).map((r:any)=><tr key={r.id}><td>{r.employee_id}</td><td>{r.name}</td><td>{r.email}</td><td>{r.role}</td><td>{r.department}</td><td>{r.designation}</td><td>{r.status}</td></tr>)}</tbody></table></div></div></main>;
}
