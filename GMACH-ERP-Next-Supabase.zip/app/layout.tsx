import "./globals.css";
import { createClient } from "@/lib/supabase/server";
import Nav from "@/components/Nav";

export const metadata = { title: "GMACH-ERP", description: "Personal ERP" };

export default async function RootLayout({children}:{children:React.ReactNode}) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return <html lang="en"><body>{user && <Nav/>}{children}{user && <div className="footer">GMACH-ERP • Personal Project</div>}</body></html>;
}
