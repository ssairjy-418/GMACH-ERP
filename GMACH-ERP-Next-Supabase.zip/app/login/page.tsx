 "use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function Login(){
 const router=useRouter(); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState("");
 const submit=async(e:FormEvent)=>{e.preventDefault();setError("");const {error}=await createClient().auth.signInWithPassword({email,password});if(error){setError(error.message);return}router.push("/");router.refresh()};
 return <div className="login"><div className="loginbox"><h1>GMACH-ERP</h1><div className="muted">Attendance • Inventory • HR</div>{error&&<div className="flash error" style={{marginTop:12}}>{error}</div>}
 <form onSubmit={submit}><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></div><div className="actions"><button className="btn" type="submit">Login</button></div></form>
 <p className="small muted" style={{marginTop:18}}>Create your first account in Supabase Auth, then add its profile using the SQL setup.</p></div></div>;
}
