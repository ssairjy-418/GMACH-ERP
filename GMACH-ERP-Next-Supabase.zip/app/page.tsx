import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
export default async function Dashboard(){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return <div className="login"><div className="loginbox"><h1>GMACH-ERP</h1><p>Personal ERP for Attendance, Inventory and HR.</p><Link className="btn" href="/login">Login</Link></div></div>;
 const [{count:employees},{count:items},{count:present},{count:leave}]=await Promise.all([
   supabase.from("employees").select("*",{count:"exact",head:true}).eq("status","Active"),
   supabase.from("inventory").select("*",{count:"exact",head:true}),
   supabase.from("attendance").select("*",{count:"exact",head:true}).eq("work_date",new Date().toISOString().slice(0,10)),
   supabase.from("leaves").select("*",{count:"exact",head:true}).eq("status","Approved").lte("from_date",new Date().toISOString().slice(0,10)).gte("to_date",new Date().toISOString().slice(0,10))
 ]);
 return <main className="wrap"><div className="title"><div><h1>Dashboard</h1><div className="muted">GMACH-ERP personal project</div></div></div>
 <div className="grid"><div className="card"><div className="muted">Active Employees</div><div className="kpi">{employees??0}</div></div><div className="card"><div className="muted">Present Today</div><div className="kpi">{present??0}</div></div><div className="card"><div className="muted">On Leave Today</div><div className="kpi">{leave??0}</div></div><div className="card"><div className="muted">Inventory Items</div><div className="kpi">{items??0}</div></div></div>
 <div className="card" style={{marginTop:14}}><h2>Quick Actions</h2><div className="actions"><Link className="btn" href="/attendance">Attendance</Link><Link className="btn" href="/inventory">Inventory</Link><Link className="btn secondary" href="/employees">HR / Employees</Link><Link className="btn light" href="/leave">Leave</Link></div></div>
 </main>;
}
