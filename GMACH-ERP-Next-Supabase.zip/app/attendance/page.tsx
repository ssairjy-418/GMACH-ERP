import { createClient } from "@/lib/supabase/server";
import AttendanceActions from "@/components/AttendanceActions";
export default async function Attendance(){
 const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)return null;
 const today=new Date().toISOString().slice(0,10);const {data:mine}=await s.from("attendance").select("*").eq("user_id",user.id).eq("work_date",today).maybeSingle();
 const {data:rows}=await s.from("attendance").select("id,work_date,check_in,check_out,employees(name,employee_id,department)").order("work_date",{ascending:false}).limit(100);
 return <main className="wrap"><div className="title"><div><h1>Attendance</h1><div className="muted">Check in and check out</div></div></div>
 <div className="card"><h2>Today</h2><p>Check-in: <b>{mine?.check_in??"-"}</b> &nbsp; Check-out: <b>{mine?.check_out??"-"}</b></p><AttendanceActions record={mine}/></div>
 <div className="card" style={{marginTop:14}}><h2>Attendance Records</h2><div className="tablewrap"><table><thead><tr><th>Date</th><th>Employee</th><th>Department</th><th>In</th><th>Out</th></tr></thead><tbody>{(rows??[]).map((r:any)=><tr key={r.id}><td>{r.work_date}</td><td>{r.employees?.name??"-"}</td><td>{r.employees?.department??"-"}</td><td>{r.check_in??"-"}</td><td>{r.check_out??"-"}</td></tr>)}</tbody></table></div></div>
 </main>;
}
