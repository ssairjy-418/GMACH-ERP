 "use client";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
export default function AttendanceActions({record}:{record:any}){
 const router=useRouter(); const supabase=createClient();
 const checkIn=async()=>{const {data:{user}}=await supabase.auth.getUser();if(!user)return;await supabase.from("attendance").upsert({user_id:user.id,work_date:new Date().toISOString().slice(0,10),check_in:new Date().toISOString()},{onConflict:"user_id,work_date"});router.refresh()};
 const checkOut=async()=>{const {data:{user}}=await supabase.auth.getUser();if(!user)return;await supabase.from("attendance").update({check_out:new Date().toISOString()}).eq("user_id",user.id).eq("work_date",new Date().toISOString().slice(0,10));router.refresh()};
 return <div className="actions">{!record?.check_in&&<button className="btn success" onClick={checkIn}>Check In</button>}{record?.check_in&&!record?.check_out&&<button className="btn danger" onClick={checkOut}>Check Out</button>}</div>;
}
