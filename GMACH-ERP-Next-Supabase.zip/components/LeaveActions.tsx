 "use client";
import {createClient} from "@/lib/supabase/client";import {useRouter} from "next/navigation";
export default function LeaveActions({id}:{id:string}){const router=useRouter();const set=async(status:"Approved"|"Rejected")=>{const {error}=await createClient().from("leaves").update({status}).eq("id",id);if(error)alert(error.message);else router.refresh()};return <div className="actions" style={{margin:0}}><button className="btn success" onClick={()=>set("Approved")}>Approve</button><button className="btn danger" onClick={()=>set("Rejected")}>Reject</button></div>}
