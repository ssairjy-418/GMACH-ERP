 "use client";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function Nav(){
  const router=useRouter();
  const logout=async()=>{await createClient().auth.signOut();router.push("/login");router.refresh()};
  return <nav className="nav"><div className="brand">GMACH-ERP</div><div className="navlinks">
    <Link href="/">Dashboard</Link><Link href="/attendance">Attendance</Link><Link href="/leave">Leave</Link><Link href="/inventory">Inventory</Link><Link href="/employees">HR</Link><Link href="/profile">Profile</Link><Link href="/change-password">Password</Link><button onClick={logout}>Logout</button>
  </div></nav>;
}
